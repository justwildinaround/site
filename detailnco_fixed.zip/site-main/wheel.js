(() => {
  "use strict";

  const init = () => {
    const wheel = document.getElementById("packageWheel");
    if (!wheel) return;

    const items = Array.from(wheel.querySelectorAll(".wheelItem"));
    if (items.length < 2) return;

    let index = 0;

    const getRadius = () => {
      const cssVal = getComputedStyle(wheel).getPropertyValue("--radius").trim();
      const r = cssVal ? parseFloat(cssVal) : NaN;
      return Number.isFinite(r) ? r : 140;
    };

    const setPositions = (activeIndex) => {
      const radius = getRadius();
      const step = (Math.PI * 2) / items.length;

      items.forEach((item, i) => {
        const posIndex = (i - activeIndex + items.length) % items.length;
        const angle = -Math.PI / 2 + posIndex * step; // active at top

        const x = Math.cos(angle) * radius;
        const y = Math.sin(angle) * radius;

        // subtle depth illusion
        const depth =
          posIndex === 0
            ? 1
            : posIndex === 1 || posIndex === items.length - 1
              ? 0.93
              : 0.88;

        // Drive transform via CSS var so CSS can't override it.
        item.style.setProperty(
          "--wheelT",
          `translate(-50%, -50%) translate(${x}px, ${y}px) scale(${depth})`
        );

        item.classList.toggle("active", i === activeIndex);
        item.style.zIndex = String(100 - posIndex);
        item.style.opacity = i === activeIndex ? "1" : "0.55";
      });
    };

    setPositions(index);

    const next = () => {
      index = (index + 1) % items.length;
      setPositions(index);
    };

    let interval = window.setInterval(next, 3500);

    items.forEach((item, i) => {
      item.addEventListener("click", () => {
        index = i;
        setPositions(index);
        const link = item.dataset.link;
        if (link) window.location.href = link;
      });

      item.addEventListener("mouseenter", () => window.clearInterval(interval));
      item.addEventListener("mouseleave", () => {
        interval = window.setInterval(next, 3500);
      });
    });

    window.addEventListener(
      "resize",
      () => {
        setPositions(index);
      },
      { passive: true }
    );
  };

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
